extends SceneTree
var latest: Dictionary = {}
var skeleton: Skeleton3D
func find_type(node: Node, kind: String) -> Node:
    if node.is_class(kind): return node
    for child in node.get_children():
        var found = find_type(child, kind)
        if found != null: return found
    return null
func _initialize() -> void:
    call_deferred("validate")
func collect_pose() -> void:
    latest.clear()
    for i in range(skeleton.get_bone_count()):
        latest[skeleton.get_bone_name(i)] = skeleton.get_bone_global_pose(i)
func ring_area(points: PackedVector3Array) -> float:
    var sum := Vector3.ZERO
    for i in range(points.size()):sum += points[i].cross(points[(i+1)%points.size()])
    return sum.length() * 0.5
func validate() -> void:
    var expected: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://expected.json"))
    var scene = load("res://Demo.tscn").instantiate()
    root.add_child(scene)
    await process_frame
    skeleton = find_type(scene, "Skeleton3D") as Skeleton3D
    var player = find_type(scene, "AnimationPlayer") as AnimationPlayer
    var modifier = skeleton.get_node("ShoulderCorrective") as SkeletonModifier3D
    modifier.modification_processed.connect(collect_pose)
    print("NATIVE_BONES=", skeleton.get_bone_count())
    assert(skeleton.get_bone_count() == 68)
    var max_position := 0.0
    var max_angle := 0.0
    var min_area := 2.0
    var max_area := 0.0
    var rows: Array = []
    var all_poses: Array = expected["poses"].duplicate(true)
    for pose in all_poses:
        player.play(pose["clip"])
        player.seek(pose["time"], true)
        player.pause()
        await process_frame
        await process_frame
        await RenderingServer.frame_post_draw
        assert(not latest.is_empty())
        var p_error := 0.0
        var q_error := 0.0
        for name in pose["bones"]:
            var ref: Dictionary = pose["bones"][name]
            var trans: Transform3D = latest[name]
            var p := Vector3(ref["p"][0],ref["p"][1],ref["p"][2])
            var q := Quaternion(ref["q"][0],ref["q"][1],ref["q"][2],ref["q"][3])
            p_error = maxf(p_error,trans.origin.distance_to(p))
            q_error = maxf(q_error,trans.basis.get_rotation_quaternion().angle_to(q))
        max_position = maxf(max_position,p_error)
        max_angle = maxf(max_angle,q_error)
        for ring in expected["rings"]:
            var index: int = skeleton.find_bone(ring["bone"])
            var rest_inverse := skeleton.get_bone_global_rest(index).affine_inverse()
            var transform: Transform3D = latest[ring["bone"]] * rest_inverse
            var a := PackedVector3Array()
            var b := PackedVector3Array()
            for row in ring["points"]:
                var p := Vector3(row[0],row[1],row[2]);a.append(p);b.append(transform*p)
            var ratio := ring_area(b)/ring_area(a)
            min_area = minf(min_area,ratio);max_area = maxf(max_area,ratio)
        var image := root.get_texture().get_image()
        image.save_png("res://capture_"+str(rows.size())+".png")
        rows.append({"clip":pose["clip"],"time":pose["time"],"max_bone_position_error_m":p_error,"max_bone_angle_error_rad":q_error})
        print("POSE ",pose["clip"]," ",pose["time"]," position_error=",p_error," angle_error=",q_error)
    var report = {"engine":Engine.get_version_info()["string"],"bones":skeleton.get_bone_count(),"poses":rows,"max_position_error_m":max_position,"max_rotation_error_rad":max_angle,"section_area_ratio_min":min_area,"section_area_ratio_max":max_area}
    var file := FileAccess.open("res://validation_report.json",FileAccess.WRITE)
    file.store_string(JSON.stringify(report,"  "));file.close()
    print("REPORT=",JSON.stringify(report))
    if max_position >= 0.0001 or max_angle >= 0.002 or min_area <= 0.999 or max_area >= 1.001:
        push_error("Native validation outside tolerance")
        quit(1)
        return
    print("NATIVE_VALIDATION_PASS")
    quit()
